/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.service;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class ClientTCP {

    private Socket comunicacao;
    private DataOutputStream enviarMsg; 
    private DataInputStream receberMsg;

    
    public ClientTCP(String ipserver, int porta) throws IOException {
        this.comunicacao = new Socket(ipserver, porta);
        this.enviarMsg = new DataOutputStream(comunicacao.getOutputStream());
        this.receberMsg = new DataInputStream(comunicacao.getInputStream());
        
    }
    //Metodos
    public void enviarMensagem (String msg) throws IOException{
        this.enviarMsg.writeUTF(msg);
        this.enviarMsg.flush();
    }
    public String receberMensagem () throws IOException{
        return this.receberMsg.readUTF();
        
    }
}
