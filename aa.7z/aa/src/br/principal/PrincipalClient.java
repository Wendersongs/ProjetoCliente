/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.principal;

import br.model.Client;
import br.service.ClientTCP;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author aluno
 */
public class PrincipalClient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws IOException {
        // TODO code application logic here
        Client cc = new Client();
        cc.setNome("Tarcisio");
        cc.setIdade(31);
        
        
        
        ClientTCP client = new ClientTCP("127.0.0.1", 7777);
        String msg = "";
        while (true) {
            //msg = JOptionPane.showInputDialog("Envie uma msg: ");
            client.enviarMensagem(cc.toString());

            System.out.println(client.receberMensagem());

        }

    }
}
